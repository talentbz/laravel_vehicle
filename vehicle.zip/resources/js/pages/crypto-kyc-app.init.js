/*
Template Name: Skote - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: Crypto KYC applicatiion Js File
*/

$(document).ready(function() {

    $("#kyc-verify-wizard").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slide"
    });
});