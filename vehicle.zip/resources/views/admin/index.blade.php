@extends('admin.layouts.index')

@section('title')
    @lang('translation.Horizontal')
@endsection

@section('content')
    <div>dashboard</div>
@endsection
